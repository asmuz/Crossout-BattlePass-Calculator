Crossout BattlePass Calculator by [XXXX]AsmuZ

1. Запусти файл "Crossout-BP-Calculator_By_AsmuZ.exe" двойным кликом
2. Выбери один из пунктов меню, введя цифру 1, 2 или 3 и подтверди выбор, нажав "Enter"
3. Введи интересующие данные и нажми "Enter"
4. Получи ответ и наслаждайся!